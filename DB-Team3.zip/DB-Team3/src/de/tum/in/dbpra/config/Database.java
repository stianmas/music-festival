package de.tum.in.dbpra.config;

public class Database {
    public static final String SERVER = "localhost";
    public static final String DATABASE = "festival";
    public static final String PORT = "5432";
    public static final String USER = "postgres";
    public static final String PASSWORD = "1juventus1";

}
