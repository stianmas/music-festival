package de.tum.in.dbpra.controller;

import de.tum.in.dbpra.model.beans.PersonBean;
import de.tum.in.dbpra.model.dao.PersonDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "ChangeNewsletterPreferenceServlet")
public class ChangeNewsletterPreferenceServlet extends HttpServlet {

    // Method handles manipulation of the user's newsletter preference in ChangeNewsletterPreference.jsp
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get the preference from radio buttons
        Boolean preference = Boolean.valueOf(request.getParameter("preference"));

        // Get current user
        PersonBean person = (PersonBean) request.getSession().getAttribute("user");

        // Create person dao
        PersonDAO personDAO = new PersonDAO();

        try {
            personDAO.changeNewsletterPreference(person, preference); // Call changeNewsletterPreference method in DAO
            request.getSession().setAttribute("user", person); // Set updated person bean
            request.setAttribute("info", "Changed Newsletter Preference Successfully!"); // Set success message
            RequestDispatcher dispatcher = request.getRequestDispatcher("/PersonalInformation.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}