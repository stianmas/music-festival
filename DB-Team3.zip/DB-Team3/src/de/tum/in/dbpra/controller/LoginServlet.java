package de.tum.in.dbpra.controller;

import de.tum.in.dbpra.model.beans.PersonBean;
import de.tum.in.dbpra.model.beans.TimetableBean;
import de.tum.in.dbpra.model.dao.PersonDAO;

import javax.servlet.RequestDispatcher;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;

@javax.servlet.annotation.WebServlet(name = "login")
public class LoginServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        try {
            PersonBean user = new PersonBean();
            String email=(request.getParameter("email"));
            String pw =(request.getParameter("password"));
            PersonDAO dao = new PersonDAO();
            // find the user matching the entered information and fill the personbean if one is found
            dao.login(user, email, pw);

            RequestDispatcher dispatcher = request.getRequestDispatcher("");
            request.getSession().setAttribute("user", user);
            // if login was successful redirect to homepage
            if (user.isLogin_status()) {
                response.sendRedirect("/Homepage.jsp");
            }
        } catch (ClassNotFoundException | SQLException e) {
           // e.printStackTrace();
            request.setAttribute("error", e.toString());
            RequestDispatcher dispatcher = request.getRequestDispatcher("/Login.jsp");
            dispatcher.forward(request, response);
        } catch (PersonDAO.FalsePasswordException e) {
            request.setAttribute("error", "Wrong information entered!");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/Login.jsp");
            dispatcher.forward(request, response);
        }

    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String action = (request.getParameter("action"));

        if(action != null && action.equals("logout")){
            request.getSession().invalidate();
            RequestDispatcher dispatcher = request.getRequestDispatcher("/Login.jsp");
            request.setAttribute("info","Successfully logged out.");
            dispatcher.forward(request, response);
        } else { //redirect
            RequestDispatcher dispatcher = request.getRequestDispatcher("/Login.jsp");
            dispatcher.forward(request, response);
        }

    }

}
