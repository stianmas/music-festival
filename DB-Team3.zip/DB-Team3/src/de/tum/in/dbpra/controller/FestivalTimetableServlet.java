package de.tum.in.dbpra.controller;

import de.tum.in.dbpra.model.beans.PersonBean;
import de.tum.in.dbpra.model.beans.TimetableBean;
import de.tum.in.dbpra.model.dao.TimetableDAO;

import javax.servlet.RequestDispatcher;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

// General remark: PersonBean user = (PersonBean) request.getSession().getAttribute("user"); gets the current logged in user.
@javax.servlet.annotation.WebServlet(name = "FestivalTimetable")
public class FestivalTimetableServlet extends javax.servlet.http.HttpServlet{

    // Method handles manipulation of the festival timetable in FestivalTimetable.jsp.
    // Used for add or remove element from personal timtable.
    // This method also handles the filtering on the table in FestivalTimetable.jsp.
    // The HttpServletRequest.getSession attibute 'currentfilter' is used to keep track of which filter is active.
    // The switch case also works as a mean to figure out which data to display. Case 'All' displays everything and Default displays for a certain date.
    // I am aware that this is a slightly ugly way to do it, but I could not find a simple jsp/html-solution for this issue. There was several easy ways
    // to make filters for normal tables, but could not find one for bootstrap. Anyways, this solution suits our needs. So it is fine for now.
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

        // Status might be remove, add, all or a date for the filter option
        String status = (request.getParameter("status"));

        if (status != null) {
            TimetableDAO tdao = new TimetableDAO();
            TimetableBean ttb1 = new TimetableBean();

            PersonBean user = (PersonBean) request.getSession().getAttribute("user");

            try {
                boolean continueSwitch = true;
                while(continueSwitch) {
                    switch (status) {
                        // removes entry from personal timetable
                        case "remove":
                            ttb1.setId(Integer.parseInt(request.getParameter("table")));
                            tdao.removeEntry(user, ttb1);
                            request.setAttribute("info", "Removed entry");

                            // Checks if a filter is active.
                            // First if-clause = display the entire table
                            // Second if-clause = date is active and only display timeslots with this date
                            // Else breaks the switch-case
                            String test = (String) request.getSession().getAttribute("currentFilter");
                            if (test != null && test.equals("All")) {
                                status = test;
                            } else if (test != null && test.length() == 10) {
                                status = test;
                            }else {
                                continueSwitch = false;
                            }
                            break;
                        // add entry to personal timetable
                        case "add":
                            ttb1.setId(Integer.parseInt(request.getParameter("table")));
                            tdao.addEntry(user, ttb1);
                            request.setAttribute("info", "Added entry");


                            // Check if there is any time conflict in users personal timetable
                            // If the result is greater than one there is conflict between performances
                            ArrayList<String[]> result = tdao.check(user, ttb1);
                            // If conflict the if == true
                            if (result.size() > 1) {
                                request.setAttribute("info2", conflictArraylistToString(result));
                            }

                            // Checks if a filter is active.
                            // First if-clause = display the entire table
                            // Second if-clause = date is active and only display timeslots with this date
                            // Else breaks the switch-case
                            test = (String) request.getSession().getAttribute("currentFilter");
                            if( test != null && test.equals("All")) {
                                status = test;
                            } else if (test != null && test.length() == 10) {
                                status = test;
                            }else {
                                continueSwitch = false;
                            }
                            break;
                        // load the full table'
                        case "All":
                            request.getSession().setAttribute("currentFilter", status);
                            doGet(request, response);
                            break;
                        // Filter festivalTimetable on value in status. Status is now a date
                        default:
                            ArrayList<TimetableBean> tb = new ArrayList<>();
                            ArrayList<TimetableBean> personalTimetable = new ArrayList<>();

                            tdao.getFestivalTimetable(tb);
                            tdao.getPersonalTimetable(user, personalTimetable);

                            // Only contains beans with date = status
                            ArrayList<TimetableBean> res = new ArrayList<>();
                            for (TimetableBean tmp : tb) {
                                if (tmp.getStartPlay().contains(status)) {
                                    res.add(tmp);
                                }
                            }
                            // Set attributes and call festivaltimetable.jsp
                            request.getSession().setAttribute("currentFilter", status);
                            request.setAttribute("dates", getFilterDates(tb));
                            request.setAttribute("festivalTimetable", res);
                            request.setAttribute("personalTimetable", personalTimetable);
                            RequestDispatcher dispatcher = request.getRequestDispatcher("/FestivalTimetable.jsp");
                            dispatcher.forward(request, response);
                            continueSwitch = false;
                            break;
                    }
                }
            } catch (ClassNotFoundException | SQLException e) {
                request.setAttribute("error", e.toString());
            }
        }
        // calls doGet to update the page with correct info
        doGet(request, response);
    }

    // Returns a list with every unique date in the list provided.
    // Provided list should always contain all timeslots.
    private ArrayList<String> getFilterDates(ArrayList<TimetableBean> festivalTimetable) {
        ArrayList<String> filter = new ArrayList<>();
        for (TimetableBean tb: festivalTimetable) {
            String tmp = tb.getStartPlay().substring(0, 10);
            if(!filter.contains(tmp)){
                filter.add(tmp);
            }
        }
        return filter;
    }

    // The print out message if entries in the personal timetable conflicts-
    // 'result' is list with conflicting entries.
    // Returns a string with all of them.
    private String conflictArraylistToString(ArrayList<String[]> result) {
        String res = "";
        for (String[] e: result) {
            for (int i = 0; i < e.length; i++) {
                res += e[i] + " ";
            }
            res += "\n";
        }
        return res;
    }

    // Get the timetable for the entire festival, sets an updated personal timetable and
    // gets the different dates in the festival in order to filter the Festival Timetable by date.
    // Then forwards to FestivalTimetable.jsp
    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        try {

            // DAO and arraylist for the timetables
            TimetableDAO dao = new TimetableDAO();
            ArrayList<TimetableBean> personalTimetable = new ArrayList<>();
            ArrayList<TimetableBean> festivalTimetable = new ArrayList<>();

            // Get list of timeslots in users personal timetable
            PersonBean user = (PersonBean) request.getSession().getAttribute("user");
            dao.getPersonalTimetable(user, personalTimetable);

            // Get festival timetable
            dao.getFestivalTimetable(festivalTimetable);

            request.setAttribute("dates", getFilterDates(festivalTimetable));
            request.setAttribute("personalTimetable", personalTimetable);
            request.setAttribute("festivalTimetable", festivalTimetable);

        } catch (ClassNotFoundException | SQLException e) {
            // e.printStackTrace();
            request.setAttribute("error", e.toString());
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("/FestivalTimetable.jsp");
        dispatcher.forward(request, response);
    }

}