package de.tum.in.dbpra.controller;

import de.tum.in.dbpra.model.beans.PersonBean;
import de.tum.in.dbpra.model.dao.PersonDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "ChangeMailServlet")
public class ChangeMailServlet extends HttpServlet {

    // Method handles manipulation of the user's email address in ChangeMail.jsp
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get user input from fields
        String newMail = request.getParameter("newMail");
        String password = request.getParameter("password");

        // Get current user
        PersonBean person = (PersonBean) request.getSession().getAttribute("user");

        // Create person dao
        PersonDAO personDAO = new PersonDAO();

        try {
            // Check if the entered old password is wrong, by calling the checkEnteredPassword method in PersonDAO
            if (!personDAO.checkEnteredPassword(person, password)) {
                request.setAttribute("error", "Entered Wrong Password. Please Try Again!"); // Set error message
                getServletContext().getRequestDispatcher("/ChangeMail.jsp").forward(request, response);
            }
            // If the entered password is correct, the email address can be updated in the db
            else {
                personDAO.changeMail(person, newMail); // Call changeMail method in DAO
                request.getSession().setAttribute("user", person); // Set updated person bean
                request.setAttribute("info", "Changed E-Mail Successfully"); // Set success message
                RequestDispatcher dispatcher = request.getRequestDispatcher("/PersonalInformation.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException | PersonDAO.FalsePasswordException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
