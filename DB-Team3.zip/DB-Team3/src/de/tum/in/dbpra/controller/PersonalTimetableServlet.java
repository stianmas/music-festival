package de.tum.in.dbpra.controller;

import de.tum.in.dbpra.model.beans.PersonBean;
import de.tum.in.dbpra.model.beans.TimetableBean;
import de.tum.in.dbpra.model.dao.TimetableDAO;

import javax.servlet.RequestDispatcher;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;

@javax.servlet.annotation.WebServlet(name = "personalTimetable")
public class PersonalTimetableServlet extends javax.servlet.http.HttpServlet {

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        try {

            //if the Servlet is called from the personalTimetable.jsp it can have an attribute to remove a row from the personal Timetable
            String action =(request.getParameter("action"));

            if (action != null && action.equals("remove")){
                TimetableDAO ttDAO1 = new TimetableDAO();

                PersonBean pb1 = (PersonBean) request.getSession().getAttribute("user");

                TimetableBean ttb1 = new TimetableBean();
                ttb1.setId(Integer.parseInt(request.getParameter("id")));
                ttDAO1.removeEntry(pb1, ttb1);
                request.setAttribute("info", "Removed entry");
            }

            // DAO and arraylist for the personal timetable
            ArrayList<TimetableBean> personalTimetable = new ArrayList<>();
            TimetableDAO ttDAO = new TimetableDAO();

            // Get list of timeslots in users personal timetable
            PersonBean pb = (PersonBean) request.getSession().getAttribute("user");
            ttDAO.getPersonalTimetable(pb, personalTimetable);
            request.setAttribute("personalTimetable", personalTimetable);

        } catch (ClassNotFoundException | SQLException e) {
            // e.printStackTrace();
            request.setAttribute("error", "Couldn't load personal timetable.");
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher("/PersonalTimetable.jsp");
        dispatcher.forward(request, response);

    }

}