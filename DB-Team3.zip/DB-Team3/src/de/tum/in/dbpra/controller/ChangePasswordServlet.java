package de.tum.in.dbpra.controller;

import de.tum.in.dbpra.model.beans.PersonBean;
import de.tum.in.dbpra.model.dao.PersonDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {

    // Method handles manipulation of the user's password in ChangePassword.jsp
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get passwords from input fields
        String oldPassword = request.getParameter("oldPassword");
        String newPassword = request.getParameter("newPassword");
        String reNewPassword = request.getParameter("reNewPassword");

        // Get current user
        PersonBean person = (PersonBean) request.getSession().getAttribute("user");

        // Create person dao
        PersonDAO personDAO = new PersonDAO();

        try {
            // Check if the entered old password is wrong, by calling the checkEnteredPassword method in PersonDAO
            if (!personDAO.checkEnteredPassword(person, oldPassword)) {
                request.setAttribute("error", "Current Password Not Correct!"); // Set error message
                getServletContext().getRequestDispatcher("/ChangePassword.jsp").forward(request, response);
            }
            // Check if the two new passwords are different
            else if (!newPassword.equals(reNewPassword)) {
                request.setAttribute("error", "Entered Passwords Do Not Match!"); // Set error message
                getServletContext().getRequestDispatcher("/ChangePassword.jsp").forward(request, response);
            }
            // Change the password
            else {
                personDAO.resetPassword(person, newPassword); // Call resetPassword method in PersonDAO
                request.getSession().setAttribute("user", person); // Set updated person bean
                request.setAttribute("info", "Changed Password Successfully!");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/PersonalInformation.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException | ClassNotFoundException | PersonDAO.FalsePasswordException e) {
            e.printStackTrace();
        }
    }
}
